import React, { Component } from 'react';
import './App.css';
import Home from './components/Home.jsx';
import Course from './components/Course.jsx';



class App extends Component {  
    
    
  render() {
    return (
      <div>
      <Home />
      </div>

    );
  }
}

export default App;
