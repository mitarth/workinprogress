import {combineReducers} from 'redux';
import isLoggedIn from './mainReducer';

const rootReducer = combineReducers({
    isLoggedIn:isLoggedIn
})

export default rootReducer;