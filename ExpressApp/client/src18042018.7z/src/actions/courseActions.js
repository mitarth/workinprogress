import * as types from '../constants/constant.js';

export function createCourse(course){
    
    return {type:types.CREATE_COURSE ,course:course}
}