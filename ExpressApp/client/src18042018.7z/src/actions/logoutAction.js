import * as types from '../constants/constant.js';

export function logout(isLoggedIn){
    
    return {type:types.LOGOUT ,isLoggedIn:isLoggedIn}
}

