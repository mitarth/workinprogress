import * as types from '../constants/constant.js';

export function login(isLoggedIn){
    
    return {type:types.LOGIN ,isLoggedIn:isLoggedIn}
}