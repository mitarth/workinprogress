import {combineReducers} from 'redux';
import isLoggedIn from './courseReducer';

const rootReducer = combineReducers({
    isLoggedIn:isLoggedIn
})

export default rootReducer;