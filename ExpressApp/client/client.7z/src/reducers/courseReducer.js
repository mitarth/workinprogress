const CREATE_COURSE = 'Create_Course';
const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';

export default function courseReducer(state={},action){
    switch(action.type){
        /*case CREATE_COURSE:
            
            return [...state,
             Object.assign({},action.course)];*/
        case LOGIN:
            
            return [state,{name:'Mitarth'} ];
        case LOGOUT:
            
            return [state, !action.isLoggedIn];
        default:
            return state;
    }
}