export const CREATE_COURSE = 'Create_Course';
export const LOGIN = 'LOGIN';